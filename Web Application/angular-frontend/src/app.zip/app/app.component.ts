import { Component, ChangeDetectorRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FilterMaskComponent } from './filter-mask/filter-mask.component';
import { GraphViewComponent } from './graph-view/graph-view.component';
import { TemporalViewComponent } from './temporal-view/temporal-view.component';
import { RangeSelectorComponent } from './range-selector/range-selector.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FilterMaskComponent, GraphViewComponent, TemporalViewComponent, RangeSelectorComponent, CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  isFilterCollapsed = false;
  labelSize = 14;
  showRepresentatives = true;
  public startDate: Date = new Date();
  public endDate: Date = new Date();
  public minDate?: Date = new Date();
  public maxDate?: Date = new Date();
  public hasMeetings: boolean = true;

  @ViewChild(TemporalViewComponent) temporalViewComponent!: TemporalViewComponent;

  constructor(private cdr: ChangeDetectorRef) {}

  toggleFilter() {
    this.isFilterCollapsed = !this.isFilterCollapsed;
  }

  public onDateRangeUpdate(range: { minDate?: Date; maxDate?: Date; hasMeetings: boolean }): void {
    this.minDate = range.minDate;
    this.maxDate = range.maxDate;
    this.hasMeetings = range.hasMeetings;
    this.cdr.detectChanges(); // Forza il rilevamento delle modifiche
  }

  // Riceve i dati dal RangeSelectorComponent
  public onDateRangeChange(dateRange: { startDate: Date; endDate: Date }): void {
    this.startDate = dateRange.startDate;
    this.endDate = dateRange.endDate;
    this.createVisualization();
    this.cdr.detectChanges();
  }

  public onLabelSizeChange(event: Event): void {
    this.labelSize = (event.target as HTMLInputElement).valueAsNumber;
    this.createVisualization();
  }

  public createVisualization(): void {
    if (this.temporalViewComponent) {
      this.temporalViewComponent.createVisualization();
    }
  }
}