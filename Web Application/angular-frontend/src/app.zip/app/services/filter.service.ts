import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})
export class FilterService {
  private filtersSubject = new BehaviorSubject<any>({});
  private meetingsSubject = new BehaviorSubject<any[]>([]);

  filters$ = this.filtersSubject.asObservable();
  meetings$ = this.meetingsSubject.asObservable();

  constructor(private dataService: DataService) {}

  // Imposta i filtri e aggiorna i meeting
  setFilters(filters: any) {
    this.filtersSubject.next(filters);
    this.fetchMeetings(filters);
  }

  // Recupera i meeting filtrati dal backend
  private fetchMeetings(filters: any) {
    this.dataService.getFilteredMeetings(filters).subscribe(
      (meetings) => {
        this.meetingsSubject.next(meetings);
      },
      (error) => console.error('Errore nel recupero dei meeting:', error)
    );
  }
}
