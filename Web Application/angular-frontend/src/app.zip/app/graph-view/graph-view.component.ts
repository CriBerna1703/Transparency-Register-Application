import { Component } from '@angular/core';

@Component({
  selector: 'app-graph-view',
  imports: [],
  templateUrl: './graph-view.component.html',
  styleUrl: './graph-view.component.css'
})
export class GraphViewComponent {

}
